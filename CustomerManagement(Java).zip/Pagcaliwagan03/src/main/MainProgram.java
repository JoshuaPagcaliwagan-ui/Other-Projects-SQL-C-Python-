/*******************************************
* This is the main program that will be used to launch the manage customer records system.
* @author Joshua O. Pagcaliwagan
* @created_date 2024-9-30 11:45 pm
********************************************/
package main;

import restaurant.Restaurant;
import java.util.Scanner;

public class MainProgram {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("^_^ Hello there, what's your name? ");//Ask user's name
        String userName = sc.nextLine();//Assign name to user input
        System.out.println("^_^ Welcome to ELiBee, " + userName + "! Select an option:");//Print greeting with user's name

        Restaurant rest = new Restaurant();//Create restaurant object
        rest.manageCustomerRecords();//Manage customer records
        sc.close();//Close scanner
    }
}