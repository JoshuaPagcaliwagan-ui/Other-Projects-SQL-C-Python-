/*******************************************
* This is the main file that contains the Customer superclass and its attributes and methods
* @author Joshua O. Pagcaliwagan
* @created_date 2024-9-30 11:45 pm
********************************************/
package customer; //from customer package

import restaurant.Restaurant; //import Restaurant class

public abstract class Customer {
    //set static variables to check customer counts, set them to protected so that subclasses can directly access them
    protected static int TOTAL_COUNT = 0;
    protected static int REGULAR_CUSTOMER_TOTAL_COUNT = 0;
    protected static int RENTER_TOTAL_COUNT = 0;

    //variables for customer info (code, name, loyalty points or balance)
    public String customer_code;
    public String name;
    public int points;

    //constructor to create customer with full name
    public Customer(String lastName, String firstName) {
        this.name = firstName + " " + lastName; // combines first and last name
        assignId(); //assigns unique ID to customer
    }

    //assigns unique ID by incrementing total count
    private void assignId() {
        TOTAL_COUNT++;
    }

    //abstract method to assign unique customer code
    public abstract void assignCode();

    //print basic customer information
    public void viewBasicInformation() {
        System.out.println("Customer Code: " + customer_code);
        System.out.println("Customer Name: " + name);
    }

    //adds amount to restaurant's sales
    public void pay(float amount, Restaurant restaurant) {
        restaurant.addToSales(amount); //calls addToSales to update sales
    }

    //abstract method for viewing customer state
    public abstract void viewState();
}
