/*******************************************
* This is the main file that contains the RegularCustomer subclass and its attributes and methods
* @author Joshua O. Pagcaliwagan
* @created_date 2024-9-18 11:45 pm
********************************************/
package customer; //from customer package

import restaurant.Restaurant; //import Restaurant class

public class RegularCustomer extends Customer {
    private static final int BASE_CODE = 1000; //since reg customers code start with 1000
    private int loyaltyPoints; //loyalty points for regular customers

    //constructor for RegularCustomer
    public RegularCustomer(String lastName, String firstName, int points) {
        super(lastName, firstName); //calls parent constructor to set name
        this.loyaltyPoints = points; //sets initial loyalty points
        REGULAR_CUSTOMER_TOTAL_COUNT++; //increments count of regular customers
        assignCode();}//assigns customer code

    @Override
    public void assignCode() {
        this.customer_code = String.valueOf(BASE_CODE + REGULAR_CUSTOMER_TOTAL_COUNT);} //sets code based on regular customer count

    //Method to simulate buy and add loyalty points
    public void buy(float amount, Restaurant restaurant) {
        if (amount > 0) {//see if buy amount is valid
            pay(amount, restaurant); //adds amount to restaurant sales
            loyaltyPoints += (int) Math.floor(amount / 25); //1 point for every P25 spent
            System.out.println("Yehey, you're so loyal, I hope everyone too :)"); //success msg
        } else {
            System.out.println("Oh no, that's invalid :(");}} //invalid msg

    @Override
    public void viewState() {
        System.out.println(customer_code + " " + name + " " + loyaltyPoints);}} //prints customer state info
