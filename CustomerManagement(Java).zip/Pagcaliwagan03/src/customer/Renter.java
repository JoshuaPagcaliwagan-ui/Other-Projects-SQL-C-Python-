/*******************************************
* This is the main file that contains the class Renter and its methods and attributes
* @author Joshua O. Pagcaliwagan
* @created_date 2024-9-30 11:45 pm
********************************************/
package customer; //from customer package

import restaurant.Restaurant; //import Restaurant class

public class Renter extends Customer {
    private static final int BASE_CODE = 2000; //2000 since renter code starts with that
    public float deposit; //deposit amount for the renter

    //constructor for renter, checks if deposit is at least 3000
    public Renter(String lastName, String firstName, float deposit) {
        super(lastName, firstName); //calls parent constructor to set name
        this.deposit = deposit >= 3000 ? deposit : 3000; //ensures minimum deposit
        RENTER_TOTAL_COUNT++; //increments count of renters
        assignCode();} //assigns the customer code

    @Override
    public void assignCode() {//assign code
        this.customer_code = String.valueOf(BASE_CODE + RENTER_TOTAL_COUNT);}//sets code based on renter count

    //method to simulate buy and deduct from deposit
    public void buy(float amount, Restaurant restaurant) {
        if (amount > 0) {//see if buy amount is valid
            if (deposit - amount >= -1000) {//see if balance doesn't fall below -1000
                pay(amount, restaurant);//adds amount to restaurant sales
                deposit -= amount;//deducts amount from deposit
                System.out.println("Yehey, you bought it :)");
            } else {
                System.out.println("Oh no, you don't have enough money :(");} //error msg
        } else {
            System.out.println("Oh no, that's invalid :(");}} //invalid msg

    @Override
    public void viewState() {
        System.out.println(customer_code + " " + name + " " + deposit);}} //prints customer state info
