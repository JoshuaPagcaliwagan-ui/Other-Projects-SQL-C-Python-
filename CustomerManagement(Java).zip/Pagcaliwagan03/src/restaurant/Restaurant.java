/*******************************************
* This is the main file that contains the manage customer records function,
* and contains the contents of the different functions involved
* @author Joshua O. Pagcaliwagan
* @created_date 2024-9-30 11:45 pm
********************************************/
package restaurant; //from restaurant package

import customer.RegularCustomer; //import RegularCustomer class
import customer.Renter; //import Renter class
import java.util.Scanner; //import Scanner for input

public class Restaurant {
    private static final int LIMIT = 50; //maximum number of customers
    private RegularCustomer[] regularCustomers = new RegularCustomer[LIMIT]; //array to hold regular customers
    private Renter[] renters = new Renter[LIMIT]; //array to hold renters
    private int regularCount = 0; //counter for regular customers
    private int renterCount = 0; //counter for renters
    private float totalSales = 0; //total sales of restaurant

    //Method to add to total sales
    public void addToSales(float amount) {
        totalSales += amount; //increment total sales by amount
    }

    // Method to manage customer records with menu
    public void manageCustomerRecords() {
        Scanner sc = new Scanner(System.in); //scanner for input
        int choice; //variable to store user choice

        do {
            System.out.println("====== Customer Records Management ======"); //menu header
            System.out.println("[1] Add customer");
            System.out.println("[2] Search customer");
            System.out.println("[3] View records");
            System.out.println("[4] Simulate sales");
            System.out.println("[5] Modify customer");
            System.out.println("[0] Exit");
            System.out.print("Enter your choice: ");

            choice = sc.nextInt(); //get user choice

            switch (choice) {//Calls function based on user choice
                case 1:
                    addCustomer(sc);
                    break;
                case 2:
                    searchCustomer(sc);
                    break;
                case 3:
                    viewRecords();
                    break;
                case 4:
                    simulateSales();
                    break;
                case 5:
                    modifyCustomer(sc);
                    break;
                case 0:
                    System.out.println("bye bye :("); //exit msg
                    break;
                default:
                    System.out.println("That's invalid :("); //invalid msg
            }
        } while (choice != 0); //continue until user selects exit
    }

    // Method to add customer based on type
    private void addCustomer(Scanner sc) {
        //ask for names and store their input
        System.out.print("Enter last name: ");
        String lastName = sc.next();
        System.out.print("Enter first name: ");
        String firstName = sc.next();

        System.out.print("Select Type:\n[a]: Regular Customer\n[b]: Renter\nEnter your choice: "); //ask customer type
        char type = sc.next().charAt(0); //store input

        if (type == 'a') { //if regular customer
            System.out.print("Enter loyalty points: "); //ask for loyalty points
            int points = sc.nextInt(); //store loyalty points
            RegularCustomer newRegular = new RegularCustomer(lastName, firstName, points); //create new regular customer
            regularCustomers[regularCount++] = newRegular; //add regular customer to array

            // Print customer details
            System.out.println(); //new line for formatting
            //print customer infos
            System.out.println("Customer ID:\t" + regularCount);
            System.out.println("Customer code:\t" + newRegular.customer_code);
            System.out.println("First name:\t" + firstName);
            System.out.println("Last name:\t" + lastName);
            System.out.println("Loyalty points:\t" + points);
        } else if (type == 'b') { //if renter
            System.out.print("Enter deposit (at least P3000): "); //ask for deposit
            float deposit = sc.nextFloat(); //store deposit
            Renter newRenter = new Renter(lastName, firstName, deposit); //create new renter
            renters[renterCount++] = newRenter; //add renter to array

            //print customer info
            System.out.println(); //new line for formatting
            System.out.println("Customer ID:\t" + renterCount);
            System.out.println("Customer code:\t" + newRenter.customer_code);
            System.out.println("First name:\t" + firstName);
            System.out.println("Last name:\t" + lastName);
            System.out.println("Remaining amount:\t" + String.format("%.2f", newRenter.deposit)); //(%.2f) for 2 decimal places

        } else {
            System.out.println("That's not a customer type :(");}}//invalid message

    // method to search for a customer by code
    private void searchCustomer(Scanner sc) {
        System.out.print("Enter customer code: "); //ask for customer code
        String customerCode = sc.next(); //store customer code
        boolean found = false; //flag for found customer

        // search in regular customers
        for (int i = 0; i < regularCount; i++) {
            if (regularCustomers[i].customer_code.equals(customerCode)) { //if code matches
                System.out.println("------- Customer Record (Regular Customers) ---------"); //header for regular customer record
                System.out.println("Code Name      Loyalty Points"); //header for details
                regularCustomers[i].viewState(); //view customer details
                found = true; //set found flag
                break;}}

        // search in renters if not in regular customers
        if (!found) {
            for (int i = 0; i < renterCount; i++) {
                if (renters[i].customer_code.equals(customerCode)) { //if code matches
                    System.out.println("------- Customer Record (Renters) ---------"); //header for renter record
                    System.out.println("Code Name            Balance"); //header for details
                    renters[i].viewState(); //view customer details
                    found = true; //set found flag
                    break;}}}

        if (!found) {
            System.out.println("Customer isn't here :(");}} //error msg

    // method to view all records
    private void viewRecords() {
        System.out.println("------- Restaurant Record ---------"); //header for restaurant record
        System.out.println("Name Total Sales"); //header for sales
        System.out.printf("EliBee\t%.2f%n", totalSales);//print total sales (%.2f% for 2 decimal places)
        System.out.println("------- Customer Record (Regular Customers) ---------"); //header for regular customers

        if (regularCount == 0) { //if no regular customers
            System.out.println("No regulars yet :("); //error message
        } else {
            System.out.println("Code Name      Loyalty Points"); //header for customer details
            for (int i = 0; i < regularCount; i++) {
                regularCustomers[i].viewState();}} //loop to view each regular customer

        System.out.println("------- Customer Record (Renters) ---------"); //header for renters
        if (renterCount == 0) { //if no renters
            System.out.println("No renters yet :("); //no entries message
        } else {
            System.out.println("Code Name            Balance"); //header for customer details
            for (int i = 0; i < renterCount; i++) {
                renters[i].viewState();}}} //view each renter

    // method to simulate sales
    private void simulateSales() {
        if (regularCount > 0 && renterCount > 0) { //check if there are enough customers
            System.out.println("START SIMULATION: CURRENT VALUES"); //simulation start message
            viewRecords(); //view initial records

            //simulate transactions for first regular customer and renter
            RegularCustomer regularCustomer = regularCustomers[0]; //get first regular customer
            Renter renterCustomer = renters[0]; //get first renter

            //first transaction for regular customer
            float regularPurchaseAmount = 75.0f; //amount for regular customer purchase
            System.out.printf("== %s trying to buy food worth P%.2f%n", regularCustomer.name, regularPurchaseAmount); //transaction message
            regularCustomer.buy(regularPurchaseAmount, this); //process purchase
            viewRecords(); //display updated records

            //second transaction for renter customer
            float renterPurchaseAmount = 85.0f; //amount for renter purchase
            System.out.printf("== %s trying to buy food worth P%.2f%n", renterCustomer.name, renterPurchaseAmount); //transaction message
            renterCustomer.buy(renterPurchaseAmount, this); //process purchase
            viewRecords(); //display updated records

            //third transaction for renter customer with a large amount
            float largeRenterPurchaseAmount = 4500.0f; //large purchase amount
            System.out.printf("== %s trying to buy food worth P%.2f%n", renterCustomer.name, largeRenterPurchaseAmount);
            renterCustomer.buy(largeRenterPurchaseAmount, this); // renter makes purchase
            viewRecords();  //view updated records after the purchase

            System.out.println("\tEND SIMULATION"); // End of simulation
        } else {
        	System.out.println("There ain't enough customers :(");}}// Error message
private void modifyCustomer(Scanner sc) { // method to modify customer details
    System.out.print("Enter customer code: "); // ask for customer code
    String customerCode = sc.next(); //read customer code
    boolean found = false; //flag to check if customer is found

    // Search in regular customers
    for (int i = 0; i < regularCount; i++) { // Loop through regular customers
        if (regularCustomers[i].customer_code.equals(customerCode)) { //check if customer code matches
            found = true; //set found flag
            System.out.println("Changing info for: " + regularCustomers[i].name); //print customer name

            //Ask user for new info
			System.out.print("Enter new first name: ");
            String newFirstName = sc.next();
            System.out.print("Enter new last name: ");
            String newLastName = sc.next();

            //update first name and last name
            regularCustomers[i].name = newFirstName + " " + newLastName; // Set new name

            //ask for new loyalty points
            System.out.print("Enter new loyalty points: ");
            int newPoints = sc.nextInt();
            regularCustomers[i].points = newPoints; // Update points

            System.out.println("Yehey, it has been changed :)");//success message
            break;}} // Exit loop

    //search in renters if not in regular customers
    if (!found) { //if customer not in regular customers
        for (int i = 0; i < renterCount; i++) { //loop through renters
            if (renters[i].customer_code.equals(customerCode)) { //check if customer code matches
                found = true; //set found flag
                System.out.println("Changing info for: " + renters[i].name); //print customer name

				//Ask for new info
                System.out.print("Enter new first name: ");
                String newFirstName = sc.next();
                System.out.print("Enter new last name: ");
                String newLastName = sc.next();

                //update first name and last name
                renters[i].name = newFirstName + " " + newLastName; //set new name

                //ask for new deposit
                System.out.print("Enter new deposit: ");
                float newDeposit = sc.nextFloat();
                renters[i].deposit = newDeposit; // update deposit

                System.out.println("Yehey, info has been changed :)"); //success message
                break;}}} //exit loop

    if (!found) { //if customer not found in both lists
        System.out.println("Customer isn't here :(");}}} // error message
